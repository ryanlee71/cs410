
<div id="header">
  <h1>Kc's Gaming Team</h1>
  <ul id="menu">
    <li><a href="/module6.php">Module 6: Week 6 Databases</a></li>
    <li><a href="/module6.php">Organizational Chart</a></li>
  </ul>
</div>