<?php
// Gamer 1
$gamer1name = "Ryan Lee";
$gamer1title = "Professional Gamer";
$gamer1favoritefood = "Chicken Adobo";
$gamer1hobby = "Playing Apex Legends";
$gamer1goals = "To try and win a world championship";

// Gamer 2
$gamer2name = "Kc Lee";
$gamer2title = "Professional Gamer";
$gamer2favoritefood = "Fried Chicken";
$gamer2hobby = "Playing League of Legends";
$gamer2goals = "To be part of a well organized team that makes it to the finals";

// Gamer 3
$gamer3name = "Ryan Kc Lee";
$gamer3title = "Professional Gamer";
$gamer3favorite_food = "Mexican food";
$gamer3hobby = "Playing Valorant";
$gamer3goals = "To play for a team that can contend for finals";
?>
